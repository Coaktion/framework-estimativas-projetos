'use client';
import { useTranslation } from 'react-i18next';
import { useLanguage } from '@/components/LanguageProvider';
import { useSession } from 'next-auth/react';
import { useRouter, useSearchParams } from 'next/navigation';

import { useState, useMemo, useCallback } from 'react';
import Link from "next/link";
import {
  Zap, Clock, Search, CheckCircle2, AlertTriangle, Shield, Filter, Lock, Globe,
} from "lucide-react";

/** Horas em formato curto: 148h, 47,5h. Evita "47.66h" na listagem. */
function formatHours(value: number): string {
  const rounded = Math.round((Number(value) || 0) * 10) / 10;
  const text = Number.isInteger(rounded)
    ? String(rounded)
    : rounded.toFixed(1).replace('.', ',');
  return `${text}h`;
}

type HistoryVersion = {
  id: number;
  version: number;
  hours: number;
  createdAt: Date;
  needsSC: boolean;
};

type HistoryGroup = {
  clientName: string;
  latestId: number;
  latestVersion: number;
  latestHours: number;
  latestCreatedAt: Date;
  latestNeedsSC: boolean;
  count: number;
  versions: HistoryVersion[];
  owner?: {
    id: number;
    name?: string;
    email?: string;
    role?: string;
  } | null;
  isAdmin?: boolean;
};

type Scope = 'mine' | 'all';

export default function AEHistoryClient(
  props: HistoryGroup & {
    groups?: HistoryGroup[];
    isAdmin?: boolean;
    currentUserId?: number;
    scope?: Scope;
  },
) {
  const { t } = useTranslation();
  const router = useRouter();
  const searchParams = useSearchParams();
  const { data: session } = useSession();

  const groups = Array.isArray(props.groups) ? props.groups : [];
  const sessionIsAdmin = props.isAdmin ??
    (Boolean((session?.user as any)?.isAdmin) ||
    (String((session?.user as any)?.role || '').toUpperCase() === 'ADMIN'));

  const initialScope = props.scope ?? (sessionIsAdmin ? 'all' : 'mine');
  const [projectScope, setProjectScope] = useState<Scope>(initialScope);

  const setScope = useCallback((next: Scope) => {
    setProjectScope(next);
    const params = new URLSearchParams(searchParams?.toString() || '');
    params.set('scope', next);
    router.push(`/ae/history?${params.toString()}`);
  }, [router, searchParams]);

  const showOwnerChip = sessionIsAdmin && projectScope === 'all';
  const [searchQuery, setSearchQuery] = useState('');

  const filteredGroups = useMemo(() => {
    const arr = Array.isArray(groups) ? groups : [];
    if (!searchQuery) return arr;
    const q = searchQuery.toLowerCase();
    return arr.filter((g) => String(g.clientName || '').toLowerCase().includes(q));
  }, [groups, searchQuery]);

  return (
    <div className="max-w-7xl mx-auto space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h1 className="text-brand-dark dark:text-[color:var(--text-main)] font-heading text-page leading-none">
            {t('aeHistory.title')} <span className="text-brand-primary dark:text-[color:var(--primary)]">{t('aeHistory.titleAccent')}</span>
          </h1>
          <p className="text-slate-400 dark:text-[color:var(--text-muted)] text-label mt-4 font-medium ">
            {t('aeHistory.projectsLabel')} ({t('aeHistory.clientCount', { count: filteredGroups.length })}{filteredGroups.length ? ` · ${t('aeHistory.versionCount', { count: filteredGroups.reduce((s, g) => s + Number(g.count || 0), 0) })}` : ''})
          </p>
          {sessionIsAdmin && (
            <p className="mt-3 inline-flex items-center gap-2 text-label font-medium text-slate-500 dark:text-[color:var(--text-muted)]">
              <Filter className="w-3 h-3" />
              <span>
                Visualizando estimativas de{' '}
                <span className="text-brand-primary dark:text-[color:var(--primary)]">
                  {projectScope === 'all'
                    ? t('aeHistory.scopeAll', 'todos os AE')
                    : t('aeHistory.scopeMine', 'apenas as minhas')}
                </span>
              </span>
            </p>
          )}
        </div>
        <div className="flex flex-col md:flex-row items-end gap-4 w-full md:w-auto">
          {sessionIsAdmin && (
            <div className="inline-flex items-center gap-1 bg-slate-50 dark:bg-[color:var(--bg-input-solid)] border border-slate-200 dark:border-[color:var(--border-main)] rounded-2xl p-1.5 shadow-sm self-start md:self-end">
              <button
                type="button"
                onClick={() => setScope('mine')}
                className={`inline-flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-caption font-medium transition-all duration-300 ${
                  projectScope === 'mine'
                    ? 'brand-bg-primary text-brand-ink shadow-md shadow-green-900/10'
                    : 'text-slate-500 dark:text-[color:var(--text-muted)] hover:text-brand-dark dark:hover:text-[color:var(--text-main)]'
                }`}
              >
                <Lock className="w-3 h-3" />
                <span>{t('aeHistory.scopeMineBtn', 'Meus')}</span>
              </button>
              <button
                type="button"
                onClick={() => setScope('all')}
                className={`inline-flex items-center gap-1.5 px-4 py-2.5 rounded-2xl text-caption font-medium transition-all duration-300 ${
                  projectScope === 'all'
                    ? 'brand-bg-primary text-brand-ink shadow-md shadow-green-900/10'
                    : 'text-slate-500 dark:text-[color:var(--text-muted)] hover:text-brand-dark dark:hover:text-[color:var(--text-main)]'
                }`}
              >
                <Globe className="w-3 h-3" />
                <span>{t('aeHistory.scopeAllBtn', 'Todos')}</span>
              </button>
            </div>
          )}
          <div className="flex flex-col md:flex-row items-center gap-4 w-full md:w-auto">
            <div className="relative w-full md:w-80 group">
              <Search className="w-4 h-4 absolute left-6 top-1/2 -translate-y-1/2 text-slate-500 dark:text-[color:var(--text-muted)] group-focus-within:text-brand-primary dark:group-focus-within:text-[color:var(--primary)] transition-colors" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t('aeHistory.searchPlaceholder')}
                className="w-full bg-white dark:bg-[color:var(--bg-card-solid)] border border-slate-500 dark:border-[color:var(--border-main)] text-brand-dark dark:text-[color:var(--text-main)] rounded-2xl pl-14 pr-6 py-4 text-label font-medium outline-none focus:ring-2 focus:ring-brand-primary/20 dark:focus:ring-[color:var(--primary)]/20 focus:border-brand-primary dark:focus:border-[color:var(--primary)] transition-all placeholder:text-slate-500 dark:placeholder:text-[color:var(--text-muted)]"
              />
            </div>
            <Link
              href="/ae"
              className="w-full md:w-auto bg-white dark:bg-[color:var(--bg-card-solid)] border border-slate-500 dark:border-[color:var(--border-main)] text-slate-500 dark:text-[color:var(--text-main)] px-8 py-5 rounded-3xl text-label font-medium flex items-center justify-center space-x-2 hover:border-brand-primary dark:hover:border-[color:var(--primary)] hover:text-brand-primary dark:hover:text-[color:var(--primary)] transition-all"
            >
              <span>{t('aeHistory.newEstimate')}</span>
            </Link>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredGroups.length === 0 ? (
          <div className="col-span-full py-24 bg-white dark:bg-[color:var(--bg-card-solid)] rounded-3xl border-4 border-dashed border-slate-50 dark:border-[color:var(--border-main)] text-center">
            <div className="brand-bg-primary w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl">
              {searchQuery ? <Search className="w-10 h-10 text-white" /> : <Zap className="w-10 h-10 text-white" />}
            </div>
            <p className="text-slate-400 dark:text-[color:var(--text-muted)] font-bold ">
              {searchQuery ? t('aeHistory.emptySearch') : t('aeHistory.emptyState')}
            </p>
          </div>
        ) : (
          filteredGroups.map((g) => (
            <ProjectCard key={g.clientName} group={g} canSeeOwner={showOwnerChip} />
          ))
        )}
      </div>
    </div>
  );
}

function ProjectCard({ group, canSeeOwner }: { group: HistoryGroup; canSeeOwner: boolean }) {
  const { t } = useTranslation();
  const { dateLocale } = useLanguage();
  const showOwnerChip = canSeeOwner;
  const orderedVersions = useMemo(
    () => [...(group.versions || [])].sort((a, b) => b.version - a.version),
    [group.versions],
  );

  return (
    <div className="group block relative">
      <div className="bg-white dark:bg-[color:var(--bg-card-solid)] rounded-3xl border border-slate-300 dark:border-[color:var(--border-main)] hover:border-brand-primary dark:hover:border-[color:var(--primary)] transition-all duration-500 shadow-xl hover:shadow-2xl overflow-hidden">
        <div className="p-10 space-y-6">
          {/* Linha 1: Data (última versão) + Tag Versão (sintética) */}
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <span className="px-4 py-1.5 rounded-xl text-caption font-medium border bg-slate-100 dark:bg-[color:var(--bg-input-solid)] text-brand-dark dark:text-[color:var(--text-main)] border-slate-200 dark:border-[color:var(--border-main)] flex items-center space-x-2">
              <Clock className="w-3.5 h-3.5" />
              <span>{new Date(group.latestCreatedAt).toLocaleDateString(dateLocale)}</span>
            </span>

            <span className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-xl text-caption font-medium border bg-slate-50 dark:bg-[color:var(--bg-input-solid)] text-slate-600 dark:text-[color:var(--text-main)] border-slate-200 dark:border-[color:var(--border-main)]">
              <Clock className="w-3.5 h-3.5" />
              <span>V{group.latestVersion} · {group.count} versões</span>
            </span>
          </div>

          {/* Nome do projeto (cliente) — clique abre a ÚLTIMA versão */}
          <Link href={`/ae/${group.latestId}`} className="block">
            <h3 className="text-2xl font-bold text-brand-dark dark:text-[color:var(--text-main)] group-hover:text-brand-primary dark:group-hover:text-[color:var(--primary)] transition-colors tracking-tight leading-tight break-words">
              {group.clientName}
            </h3>
          </Link>

          {/* chip do owner do projeto — EXCLUSIVO para admins */}
          {showOwnerChip && group.owner && (
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-xl bg-slate-100 text-brand-dark dark:bg-[color:var(--bg-input-solid)] dark:text-[color:var(--text-main)] border border-slate-200 dark:border-[color:var(--border-main)]">
              <Shield className="w-3.5 h-3.5 shrink-0" />
              <span className="text-caption font-medium ">
                {String(group.owner.name || group.owner.email || t('common.unknown') || 'Desconhecido')}
                {group.owner.role ? ` (${group.owner.role})` : ''}
              </span>
            </div>
          )}

          {/* Tag Needs SC / AE Estimate (baseada na última versão) */}
          <span className={`inline-flex items-center space-x-2 px-4 py-1.5 rounded-xl text-caption font-medium border ${
            group.latestNeedsSC
              ? 'bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-300 border-amber-100 dark:border-amber-500/30'
              : 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-300 border-emerald-100 dark:border-emerald-500/30'
          }`}>
            {group.latestNeedsSC ? (<AlertTriangle className="w-3.5 h-3.5" />) : (<CheckCircle2 className="w-3.5 h-3.5" />)}
            <span>
              {group.latestNeedsSC ? t('aeHistory.needsSC') : t('aeHistory.aeEstimate')}
              {/* Estimativa que exige SE não tem número fechado — mostrar horas
                  ali passaria a ideia de um valor acordado que não existe. */}
              {!group.latestNeedsSC && group.latestHours > 0
                ? ` · ${formatHours(group.latestHours)}`
                : ''}
            </span>
          </span>

          {/* Lista resumida das versões (chips clicáveis) */}
          <div className="pt-4 mt-4 border-t border-slate-100 dark:border-[color:var(--border-main)]">
            <p className="text-caption font-medium text-slate-400 dark:text-[color:var(--text-muted)] mb-2.5">
              {t('common.versions')}
            </p>
            <div className="flex flex-wrap gap-2">
              {orderedVersions.map((v) => {
                const latest = Number(v.id) === Number(group.latestId);
                return (
                  <Link
                    key={String(v.id)}
                    href={`/ae/${v.id}`}
                    className={`
                      inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-caption font-medium   border transition-all
                      ${latest
                        ? 'brand-bg-primary text-brand-ink border-brand-primary shadow-md shadow-green-900/10'
                        : v.needsSC
                          ? 'bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-300 border-amber-100 dark:border-amber-500/30 hover:border-amber-400 dark:hover:border-amber-500 hover:text-amber-700 dark:hover:text-amber-200'
                          : 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-300 border-emerald-100 dark:border-emerald-500/30 hover:border-emerald-400 dark:hover:border-emerald-500 hover:text-emerald-700 dark:hover:text-emerald-200'
                      }
                    `}
                  >
                    {v.needsSC
                      ? <AlertTriangle className="w-3.5 h-3.5" />
                      : <CheckCircle2 className="w-3.5 h-3.5" />}
                    <span>
                      V{v.version}
                      {v.needsSC
                        ? ` · ${t('aeHistory.scShort')}`
                        : v.hours > 0 ? ` · ${formatHours(v.hours)}` : ''}
                    </span>
                  </Link>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
