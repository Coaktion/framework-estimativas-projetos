var HC = HelpCenter;
var userLoggedin;

function closeAlert(e) {
    e.parentElement.style.display = 'none';
    headerFixedHeight();
}

function headerFixedHeight() {
    let fixedHeight = document.querySelector('.header-wrapper').offsetHeight + 'px';
    document.querySelector('.for-header-fixed').style.height = fixedHeight;
}

document.addEventListener('DOMContentLoaded', function() {

    // for custom field view
    if (HC.user.role !== 'anonymous') {
        fetch('/api/v2/users/me.json')
            .then(response => response.json())
            .then(user => {
                if (user.user.authenticity_token) {
                    userLoggedin = user.user;
                }
            })
    }

    function linkMenu(data) {
        if (data.innerHTML.trim()) {
            var listArray = data.innerHTML.trim().split(',');
            data.innerHTML = '';
            listArray.forEach(function(item) {
                if (item) {
                    let linkMenu = item.split(';');

                    if (linkMenu[0].substring(0, 3) == "fa-") {
                        linkMenu[0] = "<i class='fas " + linkMenu[0] + " '></i>";
                    }

                    if (linkMenu[1]) {
                        data.innerHTML += '<a href="' + linkMenu[1] + '">' + linkMenu[0] + '</a>';
                    } else {
                        data.innerHTML += '<a href="javascript:;">' + linkMenu[0] + '</a>';
                    }
                }
            });
        }
    }

    //for fixed header
    if (document.querySelector('.for-header-fixed')) {
        headerFixedHeight();
    }

    // for top menu 
    if (document.querySelector('.sub-header .sub-menu')) {
        linkMenu(document.querySelector('.sub-header .sub-menu'));
    }

    // for section footer menu
    if (document.querySelector('.footer-request-btn')) {
        linkMenu(document.querySelector('.footer-request-btn'));
    }

    // for stickey header
    if (document.querySelector(".header-sticky")) {
        let headerSticky = document.querySelector(".header-sticky");
        let headerStickyClone = headerSticky.cloneNode(true);
        headerStickyClone.classList.add("clone");
        insertAfter(headerSticky, headerStickyClone);

        window.onscroll = function() {
            if (this.pageYOffset > document.querySelector('.header-wrapper').offsetHeight) {
                document.body.classList.add("down");
            } else {
                document.body.classList.remove("down");
            }
        };
    }

    function insertAfter(referenceNode, newNode) {
        referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);
    }

    function wrap(el, wrapper) {
        el.parentNode.insertBefore(wrapper, el);
        wrapper.appendChild(el);
    }

    // for button new request layout
    if (document.querySelector('.request-btn-layout')) {
        let objTicketMap = {};
        let selectRequestType = document.getElementById('request_issue_type_select');
        let btnLayout = document.querySelector('.request-btn-layout');
        if (selectRequestType) {
            for (let i = 0; i < selectRequestType.length; i++) {
                var optionRequestType = selectRequestType.options[i];
                objTicketMap[optionRequestType.value] = optionRequestType.innerHTML;
                if (optionRequestType.innerHTML != '-' && selectRequestType.value == '-') {
                    btnLayout.innerHTML += '<a class="transition request-btn-link" href="' + optionRequestType.attributes['data-url']['value'] + '">' + optionRequestType.innerHTML + '</a>';
                }
                if (selectRequestType.value != '-') {
                    document.querySelector('.request_ticket_form_id').style.display = 'none';
                    document.querySelector('.request-btn-layout h1').innerHTML = '<a class="transition go-back" href="' + window.location.pathname + '"><i class="fas fa-chevron-left"></i></a>' + objTicketMap[selectRequestType.value];
                    if (document.querySelector('.request-btn-link')) {
                        document.querySelectorAll('.request-btn-link').forEach(function(el) {
                            el.style.display = 'none';
                        });
                    }
                } else {
                    document.querySelector('.request-btn-layout .request-form').style.display = 'none';
                }
            }
        }
    }

    //for custom checkbox layout
    if (document.querySelector('.request-layout input[type="checkbox"]')) {
        document.querySelectorAll('.request-layout input[type="checkbox"]').forEach(function(checkbox) {
            var checboxWrap = document.createElement('label');
            checboxWrap.setAttribute("class", "checkbox-wrap");
            wrap(checkbox, checboxWrap);
            var el = document.createElement('span');
            el.classList.add("checkmark");
            insertAfter(checkbox, el);
        });
    }

    // for alert link
    if (document.querySelector('.alert-box-content')) {
        var alertBoxContent = document.querySelector('.alert-box-content').innerHTML;
        var curlyBracesWrap = alertBoxContent.match(/{.+?}/g);

        if (curlyBracesWrap) {
            curlyBracesWrap.forEach(function(link) {
                let newLink = link.replace(/[{}]/g, "").split(';');
                newLink = '<a href="' + newLink[1] + '">' + newLink[0] + '</a>';
                alertBoxContent = alertBoxContent.replace(link, newLink);
            });
        }

        document.querySelector('.alert-box-content').innerHTML = alertBoxContent;
    }



    // Key map
    var ENTER = 13;
    var ESCAPE = 27;
    var SPACE = 32;
    var UP = 38;
    var DOWN = 40;
    var TAB = 9;

    function closest(element, selector) {
        if (Element.prototype.closest) {
            return element.closest(selector);
        }
        do {
            if (Element.prototype.matches && element.matches(selector) ||
                Element.prototype.msMatchesSelector && element.msMatchesSelector(selector) ||
                Element.prototype.webkitMatchesSelector && element.webkitMatchesSelector(selector)) {
                return element;
            }
            element = element.parentElement || element.parentNode;
        } while (element !== null && element.nodeType === 1);
        return null;
    }

    // social share popups
    Array.prototype.forEach.call(document.querySelectorAll('.share a'), function(anchor) {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            window.open(this.href, '', 'height = 500, width = 500');
        });
    });

    // In some cases we should preserve focus after page reload
    function saveFocus() {
        var activeElementId = document.activeElement.getAttribute("id");
        sessionStorage.setItem('returnFocusTo', '#' + activeElementId);
    }
    var returnFocusTo = sessionStorage.getItem('returnFocusTo');
    if (returnFocusTo) {
        sessionStorage.removeItem('returnFocusTo');
        var returnFocusToEl = document.querySelector(returnFocusTo);
        returnFocusToEl && returnFocusToEl.focus && returnFocusToEl.focus();
    }

    // show form controls when the textarea receives focus or backbutton is used and value exists
    var commentContainerTextarea = document.querySelector('.comment-container textarea'),
        commentContainerFormControls = document.querySelector('.comment-form-controls, .comment-ccs');

    if (commentContainerTextarea) {
        commentContainerTextarea.addEventListener('focus', function focusCommentContainerTextarea() {
            commentContainerFormControls.style.display = 'block';
            commentContainerTextarea.removeEventListener('focus', focusCommentContainerTextarea);
        });

        if (commentContainerTextarea.value !== '') {
            commentContainerFormControls.style.display = 'block';
        }
    }

    // Expand Request comment form when Add to conversation is clicked
    var showRequestCommentContainerTrigger = document.querySelector('.request-container .comment-container .comment-show-container'),
        requestCommentFields = document.querySelectorAll('.request-container .comment-container .comment-fields'),
        requestCommentSubmit = document.querySelector('.request-container .comment-container .request-submit-comment');

    if (showRequestCommentContainerTrigger) {
        showRequestCommentContainerTrigger.addEventListener('click', function() {
            showRequestCommentContainerTrigger.style.display = 'none';
            Array.prototype.forEach.call(requestCommentFields, function(e) { e.style.display = 'block'; });
            requestCommentSubmit.style.display = 'inline-block';

            if (commentContainerTextarea) {
                commentContainerTextarea.focus();
            }
        });
    }

    // Mark as solved button
    var requestMarkAsSolvedButton = document.querySelector('.request-container .mark-as-solved:not([data-disabled])'),
        requestMarkAsSolvedCheckbox = document.querySelector('.request-container .comment-container input[type=checkbox]'),
        requestCommentSubmitButton = document.querySelector('.request-container .comment-container input[type=submit]');

    if (requestMarkAsSolvedButton) {
        requestMarkAsSolvedButton.addEventListener('click', function() {
            requestMarkAsSolvedCheckbox.setAttribute('checked', true);
            requestCommentSubmitButton.disabled = true;
            this.setAttribute('data-disabled', true);
            // Element.closest is not supported in IE11
            closest(this, 'form').submit();
        });
    }

    // Change Mark as solved text according to whether comment is filled
    var requestCommentTextarea = document.querySelector('.request-container .comment-container textarea');

    if (requestCommentTextarea) {
        requestCommentTextarea.addEventListener('input', function() {
            if (requestCommentTextarea.value === '') {
                if (requestMarkAsSolvedButton) {
                    requestMarkAsSolvedButton.innerText = requestMarkAsSolvedButton.getAttribute('data-solve-translation');
                }
                requestCommentSubmitButton.disabled = true;
            } else {
                if (requestMarkAsSolvedButton) {
                    requestMarkAsSolvedButton.innerText = requestMarkAsSolvedButton.getAttribute('data-solve-and-submit-translation');
                }
                requestCommentSubmitButton.disabled = false;
            }
        });
    }

    // Disable submit button if textarea is empty
    if (requestCommentTextarea && requestCommentTextarea.value === '') {
        requestCommentSubmitButton.disabled = true;
    }

    // Submit requests filter form on status or organization change in the request list page
    Array.prototype.forEach.call(document.querySelectorAll('#request-status-select, #request-organization-select'), function(el) {
        el.addEventListener('change', function(e) {
            e.stopPropagation();
            saveFocus();
            closest(this, 'form').submit();
        });
    });

    // Submit requests filter form on search in the request list page
    var quickSearch = document.querySelector('#quick-search');
    quickSearch && quickSearch.addEventListener('keyup', function(e) {
        if (e.keyCode === ENTER) {
            e.stopPropagation();
            saveFocus();
            closest(this, 'form').submit();
        }
    });

    function toggleNavigation(toggle, menu) {
        var isExpanded = menu.getAttribute('aria-expanded') === 'true';
        menu.setAttribute('aria-expanded', !isExpanded);
        toggle.setAttribute('aria-expanded', !isExpanded);
    }

    function closeNavigation(toggle, menu) {
        menu.setAttribute('aria-expanded', false);
        toggle.setAttribute('aria-expanded', false);
        toggle.focus();
    }

    var burgerMenu = document.querySelector('.header .menu-button');
    var userMenu = document.querySelector('#user-nav');

    burgerMenu.addEventListener('click', function(e) {
        e.stopPropagation();
        toggleNavigation(this, userMenu);
    });


    userMenu.addEventListener('keyup', function(e) {
        if (e.keyCode === ESCAPE) {
            e.stopPropagation();
            closeNavigation(burgerMenu, this);
        }
    });

    if (userMenu.children.length === 0) {
        burgerMenu.style.display = 'none';
    }

    // Toggles expanded aria to collapsible elements
    var collapsible = document.querySelectorAll('.collapsible-nav, .collapsible-sidebar');

    Array.prototype.forEach.call(collapsible, function(el) {
        var toggle = el.querySelector('.collapsible-nav-toggle, .collapsible-sidebar-toggle');

        el.addEventListener('click', function(e) {
            toggleNavigation(toggle, this);
        });

        el.addEventListener('keyup', function(e) {
            if (e.keyCode === ESCAPE) {
                closeNavigation(toggle, this);
            }
        });
    });

    // Submit organization form in the request page
    var requestOrganisationSelect = document.querySelector('#request-organization select');

    if (requestOrganisationSelect) {
        requestOrganisationSelect.addEventListener('change', function() {
            closest(this, 'form').submit();
        });
    }

    // If a section has more than 6 subsections, we collapse the list, and show a trigger to display them all
    var seeAllTrigger = document.querySelector("#see-all-sections-trigger");
    var subsectionsList = document.querySelector(".section-list");

    if (subsectionsList && subsectionsList.children.length > 6) {
        seeAllTrigger.setAttribute("aria-hidden", false);

        seeAllTrigger.addEventListener("click", function(e) {
            subsectionsList.classList.remove("section-list--collapsed");
            seeAllTrigger.parentNode.removeChild(seeAllTrigger);
        });
    }

    // If multibrand search has more than 5 help centers or categories collapse the list
    var multibrandFilterLists = document.querySelectorAll(".multibrand-filter-list");
    Array.prototype.forEach.call(multibrandFilterLists, function(filter) {
        if (filter.children.length > 6) {
            // Display the show more button
            var trigger = filter.querySelector(".see-all-filters");
            trigger.setAttribute("aria-hidden", false);

            // Add event handler for click
            trigger.addEventListener("click", function(e) {
                e.stopPropagation();
                trigger.parentNode.removeChild(trigger);
                filter.classList.remove("multibrand-filter-list--collapsed")
            })
        }
    });

    // If there are any error notifications below an input field, focus that field
    var notificationElm = document.querySelector(".notification-error");
    if (
        notificationElm &&
        notificationElm.previousElementSibling &&
        typeof notificationElm.previousElementSibling.focus === "function"
    ) {
        notificationElm.previousElementSibling.focus();
    }

    // Dropdowns

    function Dropdown(toggle, menu) {
        this.toggle = toggle;
        this.menu = menu;

        this.menuPlacement = {
            top: menu.classList.contains("dropdown-menu-top"),
            end: menu.classList.contains("dropdown-menu-end")
        };

        this.toggle.addEventListener("click", this.clickHandler.bind(this));
        this.toggle.addEventListener("keydown", this.toggleKeyHandler.bind(this));
        this.menu.addEventListener("keydown", this.menuKeyHandler.bind(this));
    };

    Dropdown.prototype = {

        get isExpanded() {
            return this.menu.getAttribute("aria-expanded") === "true";
        },

        get menuItems() {
            return Array.prototype.slice.call(this.menu.querySelectorAll("[role='menuitem']"));
        },

        dismiss: function() {
            if (!this.isExpanded) return;

            this.menu.setAttribute("aria-expanded", false);
            this.menu.classList.remove("dropdown-menu-end", "dropdown-menu-top");
        },

        open: function() {
            if (this.isExpanded) return;

            this.menu.setAttribute("aria-expanded", true);
            this.handleOverflow();
        },

        handleOverflow: function() {
            var rect = this.menu.getBoundingClientRect();

            var overflow = {
                right: rect.left < 0 || rect.left + rect.width > window.innerWidth,
                bottom: rect.top < 0 || rect.top + rect.height > window.innerHeight
            };

            if (overflow.right || this.menuPlacement.end) {
                this.menu.classList.add("dropdown-menu-end");
            }

            if (overflow.bottom || this.menuPlacement.top) {
                this.menu.classList.add("dropdown-menu-top");
            }

            if (this.menu.getBoundingClientRect().top < 0) {
                this.menu.classList.remove("dropdown-menu-top")
            }
        },

        focusNextMenuItem: function(currentItem) {
            if (!this.menuItems.length) return;

            var currentIndex = this.menuItems.indexOf(currentItem);
            var nextIndex = currentIndex === this.menuItems.length - 1 || currentIndex < 0 ? 0 : currentIndex + 1;

            this.menuItems[nextIndex].focus();
        },

        focusPreviousMenuItem: function(currentItem) {
            if (!this.menuItems.length) return;

            var currentIndex = this.menuItems.indexOf(currentItem);
            var previousIndex = currentIndex <= 0 ? this.menuItems.length - 1 : currentIndex - 1;

            this.menuItems[previousIndex].focus();
        },

        clickHandler: function() {
            if (this.isExpanded) {
                this.dismiss();
            } else {
                this.open();
            }
        },

        toggleKeyHandler: function(e) {
            switch (e.keyCode) {
                case ENTER:
                case SPACE:
                case DOWN:
                    e.preventDefault();
                    this.open();
                    this.focusNextMenuItem();
                    break;
                case UP:
                    e.preventDefault();
                    this.open();
                    this.focusPreviousMenuItem();
                    break;
                case ESCAPE:
                    this.dismiss();
                    this.toggle.focus();
                    break;
            }
        },

        menuKeyHandler: function(e) {
            var firstItem = this.menuItems[0];
            var lastItem = this.menuItems[this.menuItems.length - 1];
            var currentElement = e.target;

            switch (e.keyCode) {
                case ESCAPE:
                    this.dismiss();
                    this.toggle.focus();
                    break;
                case DOWN:
                    e.preventDefault();
                    this.focusNextMenuItem(currentElement);
                    break;
                case UP:
                    e.preventDefault();
                    this.focusPreviousMenuItem(currentElement);
                    break;
                case TAB:
                    if (e.shiftKey) {
                        if (currentElement === firstItem) {
                            this.dismiss();
                        } else {
                            e.preventDefault();
                            this.focusPreviousMenuItem(currentElement);
                        }
                    } else if (currentElement === lastItem) {
                        this.dismiss();
                    } else {
                        e.preventDefault();
                        this.focusNextMenuItem(currentElement);
                    }
                    break;
                case ENTER:
                case SPACE:
                    e.preventDefault();
                    currentElement.click();
                    break;
            }
        }
    }

    var dropdowns = [];
    var dropdownToggles = Array.prototype.slice.call(document.querySelectorAll(".dropdown-toggle"));

    dropdownToggles.forEach(function(toggle) {
        var menu = toggle.nextElementSibling;
        if (menu && menu.classList.contains("dropdown-menu")) {
            dropdowns.push(new Dropdown(toggle, menu));
        }
    });

    document.addEventListener("click", function(evt) {
        dropdowns.forEach(function(dropdown) {
            if (!dropdown.toggle.contains(evt.target)) {
                dropdown.dismiss();
            }
        });
    });
});